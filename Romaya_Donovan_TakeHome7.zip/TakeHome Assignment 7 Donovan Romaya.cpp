// TakeHome Assignment 7 Donovan Romaya.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "ShallowClass.h"
#include "DeepClass.h"
using namespace std;

int main()
{
    cout << boolalpha;
    cout << "------ShallowClass: Output Values and Locations after an equivalence operator--------" << endl;
    //TODO Create the two ShallowClass Objects, and use the equivalence operator "="
    //     Output them using toString, then call both ShallowEqual and DeepEqual
    ShallowClass Shallow1(5, 7);
    ShallowClass Shallow2;

    Shallow2 = Shallow1;

    cout << Shallow1.toString() << endl;
    cout << endl;
    cout << Shallow2.toString() << endl;
    cout << endl;

    cout << "First Shallow equals second? " << Shallow1.ShallowEqual(Shallow2) << endl;
    cout << "First Deep equals second? " << Shallow1.DeepEqual(Shallow2) << endl;
    cout << endl;

    cout << "---------Set Values of Second Object and toString Again -----------" << endl;
    //TODO call both setters on the second object, then call toString on both objects again
    Shallow2 = ShallowClass(10, 20);
    Shallow1.setPtr(20);
    
    cout << Shallow1.toString() << endl;
    cout << endl;

    cout << Shallow2.toString() << endl;
    cout << endl;

    cout << "------DeepClass: Output Values and Locations after an equivalence operator--------" << endl;
    //TODO Create two DeepClass Objects, and use the equivalence operator "="
    //     Output them using toString, then call both ShallowEqual and DeepEqual
    DeepClass Deep1(8, 9);
    DeepClass Deep2;
    Deep2 = Deep1;

    cout << Deep1.toString() << endl;
    cout << endl;
    cout << Deep2.toString() << endl;
    cout << endl;

    cout << "Third Shallow equals fourth ? " << Deep1.ShallowEqual(Deep2) << endl;
    cout << "Third Deep equals fourth ? " << Deep1.DeepEqual(Deep2) << endl;
    cout << endl;

    cout << "---------Set Values of Fourth Object and toString Again -----------" << endl;
    //TODO call both setters on the fourth object, then call toString on both objects again

    Deep2.setInt(8);
    Deep2.setPtr(9);
    cout << Deep2.toString() << endl;
    cout << endl;

    Deep2.setInt(30);
    Deep2.setPtr(40);
    cout << Deep2.toString() << endl;
    cout << endl;

    cout << "------DeepClass: Output Values and Locations after a copy constructor--------" << endl;
    //TODO Create another DeepClass object, by explicitly using the copy constructor with one of the existing DeepClass objects
    //     Call toString on the these two objects

    DeepClass Deep3(Deep2);
    
    cout << Deep2.toString() << endl;
    cout << endl;
    cout << Deep3.toString() << endl;
    cout << endl;

    cout << "---------Set Values of each Object and toString Again -----------" << endl;
    //TODO Call setInt on one DeepClass object, and setPtr on the other. Use toString again

    Deep2.setInt(5000);
    cout << Deep2.toString() << endl;
    cout << endl;

    Deep1.setPtr(1000);
    cout << Deep1.toString() << endl;
    cout << endl;

    cout << "-----------Does a ShallowObject DeepEqual itself? What about a DeepObject?---------" << endl;
    //TODO Use DeepEqual on both a ShallowClass object and DeepClass object. Both making the comparison to themselves.
    //     Write a comment explaining the results, and why they occur
    cout << "First Deep equals First? " << Shallow1.DeepEqual(Shallow1) << endl;

    cout << "Third Deep equals Third? " << Deep3.DeepEqual(Deep3) << endl;
}

//The reason why the Deep classes are not equal to eachother using DeepEqual is because one of them is a copy of the other. A copy is not the original.