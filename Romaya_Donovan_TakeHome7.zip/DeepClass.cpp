#include "DeepClass.h"

//Implement the DeepClass functions as defined in the header and described in the assignment

DeepClass::DeepClass() {
	myInt = 0;
	myPtr = nullptr;

}


DeepClass::DeepClass(int iv, int pv) {
	myInt = iv;
	myPtr = new int(pv);

}

DeepClass::DeepClass(const DeepClass& other) {
	myInt = other.myInt;
	myPtr = new int;
	*myPtr = (*(other.myPtr));
	cout << "Copy Constructor has been called!" << endl;

}

DeepClass& DeepClass::operator=(const DeepClass& other) {
	if (this != &other) {
		delete myPtr;
		myPtr = new int;
		*myPtr = *(other.myPtr);
		myInt = other.myInt;
	}
	cout << "Equals Operator has been called!" << endl;
	return *this;

}

void DeepClass::setInt(int iv) {
	myInt = iv;
}

void DeepClass::setPtr(int pv) {
	*myPtr = pv;
}

int DeepClass::getInt() {
	return myInt;
}

int DeepClass::getPtr() {
	return *myPtr;
}

string DeepClass::toString() {
	stringstream deep;
	deep << "Int Value: " << myInt << " Location: " << &myInt << "\n" << "Pointer Value: " << *myPtr << " Location: " << myPtr;
	return deep.str();
}

bool DeepClass::ShallowEqual(DeepClass other) {
	return myInt == other.myInt && *myPtr == *(other.myPtr);
}

bool DeepClass::DeepEqual(DeepClass other) {
	return myInt == other.myInt && myPtr == other.myPtr;
}

DeepClass::~DeepClass() {
	delete myPtr;
}