#include "ShallowClass.h"

//Implement The ShallowClass functions as defined in the header and described in the assignment

ShallowClass::ShallowClass() {
	myInt = 0;
	myPtr = nullptr;
}


ShallowClass::ShallowClass(int iv, int pv) {
	myInt = iv;
	myPtr = new int(pv);

}

void ShallowClass::setInt(int iv) {
	myInt = iv;

}


void ShallowClass::setPtr(int pv) {
	*myPtr = pv;

}


int ShallowClass::getInt() {
	return myInt;
}


int ShallowClass::getPtr() {
	return *myPtr;

}

string ShallowClass::toString() {
	stringstream shall;
	shall << "Int Value: " << myInt << " Location: " << &myInt << "\n" << "Pointer Value: " << *myPtr << " Location: " << myPtr;
	return shall.str();

}

bool ShallowClass::ShallowEqual(ShallowClass other) {

	return myInt == other.myInt && *myPtr == *(other.myPtr);
}

bool ShallowClass::DeepEqual(ShallowClass other) {

	return myInt == other.myInt && myPtr == other.myPtr;
}