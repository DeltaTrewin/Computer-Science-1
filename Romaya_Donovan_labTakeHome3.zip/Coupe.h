#pragma once
#include "Car.h"
class Coupe : public Car
{
private:
	int safetyRating;
public:
	Coupe();
	Coupe(string, string, string, int, int, int);
	string toString();
};