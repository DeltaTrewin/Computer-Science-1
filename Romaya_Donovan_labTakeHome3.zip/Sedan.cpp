#include "Sedan.h"
#include <string>
using namespace std;
Sedan::Sedan(){
	make = "none";
	model = "none";
	color = "none";
	year = 0;
	MPG = 0;
	numOfAirbags = 0;
}

Sedan::Sedan(string ma, string mo, string co, int ye, int M, int bag):Car(ma, mo, co, ye, M) {

	this-> numOfAirbags = bag;

}


string Sedan::toString() {
	return Car::toString() + " Number of Airbags: " + to_string(numOfAirbags);

}