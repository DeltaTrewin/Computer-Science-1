#include "SUV.h"
#include <string>
using namespace std;

SUV::SUV(){

	make = "none";
	model = "none";
	color = "none";
	year = 0;
	MPG = 0;
	numOfSeats = 0;

}


SUV::SUV(string ma, string mo, string co, int ye, int M, int SE):Car(ma, mo, co, ye, M){
	this-> numOfSeats = SE;

}


string SUV::toString(){
	return Car::toString() + " Number of Seats: " + to_string(numOfSeats);
}
