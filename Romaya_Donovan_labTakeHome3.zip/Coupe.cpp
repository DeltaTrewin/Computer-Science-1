#include "Coupe.h"
#include <string>
using namespace std;
Coupe::Coupe() {

	make = "none";
	model = "none";
	color = "none";
	year = 0;
	MPG = 0;
	safetyRating = 0;

}
Coupe::Coupe(string ma, string mo, string co, int ye, int M, int safetyRating) :Car(ma, mo, co, ye, M) {
	this -> safetyRating = safetyRating;

}


string Coupe::toString() {
	return Car::toString() + " Safety Rating: " + to_string(safetyRating);

}