#include "Car.h"
#include <string>
#include <vector>
using namespace std;
Car::Car() {

	this->make = "none";
	this->model = "none";
	this->color = "none";
	this->year = 0;
	this->MPG = 0;

}

Car::Car(string ma, string mo, string co, int ye, int M) {
	this->make = ma;
	this->model = mo;
	this->color = co;
	this->year = ye;
	this->MPG = M;
}


string Car::getMake() {
	return make;
}
string Car::getModel() {
	return model;
}


string Car::getColor() {
	return color;
}

int Car::getYear() {
	return year;
}

int Car::getMPG() {
	return MPG;
}

void Car::setMake(string ma) {
	make =  ma;
}


void Car::setModel(string mo) {
	model = mo;
}


void Car::setColor(string co) {
	color = co;

}
void Car::setYear(int ye) {
	year = ye;

}


void Car::setMPG(int M) {
	MPG = M;

}

string Car::toString() {
	return "Make: " + make + " Model: " + model + " Color " + color + " Year: " + to_string(year) + " MPG: " + to_string(MPG);
	
}

vector<Car*> makeVector(int num) {
	return vector<Car*>(num);

}


void paintVector(vector<Car*> cars, string newColor) {
	for (int i = 0; i < cars.size(); i++){
		cars[i] -> setColor(newColor);
	}
	
}
