#include "Truck.h"
#include <string>
using namespace std;

Truck::Truck(){
	make = "none";
	model = "none";
	color = "none";
	year = 0;
	MPG = 0;
	bedCapacity = 0;

}

Truck::Truck(string ma, string mo, string co, int ye, int M, int bedCapacity):Car(ma, mo, co, ye, M) {

	this -> bedCapacity = bedCapacity;
}


string Truck::toString(){
	return Car::toString() + " Number of Bed Capacity: " + to_string(bedCapacity);
}
