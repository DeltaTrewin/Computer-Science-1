#include <vector>
#include <iostream>
#include <string>
#include <random>
using namespace std;

bool isPalindrome_helper(string k) {
	//TODO return true if k reads the same forwards and backwards
	//The string functions size() and substr() will be handy
	//This function should call itself recursively
	if (k.size() <= 1) {
		return true;
	}

	if (k[0] == k[k.size() - 1]) {
		return  isPalindrome_helper(k.substr(1, k.size() - 2));
	}
	
	return false;
}

bool isPalindrome(string k) {
	//TODO: Remove all whitespace from the string, and call the helper function
	//The string functions erase(), and remove_if() will be handy for this processing
	int i;
	size_t WS = k.find(' ');
	while (WS != string::npos) {
		k.erase(WS, 1);
		WS = k.find(' ');
	}
	

	//cout << k << endl; //Test to see if white-space is removed
	return isPalindrome_helper(k);
	
}

string rearrange(string k) {
	//TODO: returns the string k scrambled into a random order
	//The functions size(), substr(), erase(), and rand() will be useful
	int i, j; 
	char SW;
	for (i = k.size() - 1; i > 0; i--) {
		j = rand() % (1 + 1);
		SW = k[i];
		k[i] = k[j];
		k[j] = SW;
	}
	return k;
}

vector<vector<int>> p_triangle_helper(int row, int goal, vector<vector<int>> res) {
	//TODO: use recursion to add rows to res until the goal value is reached
	//HINT: A for loop is useful in this function, even though it calls itself at the end
	int i;
	if (row == goal) {
		return res;
	}

	vector<int> next;
	if (res.empty()) {
		next.push_back(1);
	}
	else {
		next.push_back(1);
		for (i = 1; i < res.size(); i++) {
			next.push_back(res.back().at(i - 1) + res.back().at(i));
		}
		next.push_back(1);
	}
	res.push_back(next);
	return p_triangle_helper(row + 1, goal, res);
}

vector<vector<int>> p_triangle(int k) {
	//TODO: return a vector of vectors of ints forming a pascal triangle of k rows
	//Each vector is one of those rows
	//This function essentially just calls the helper with the appropriate parameters
	vector<vector<int>> res;
	return  p_triangle_helper(0, k, res);
	
}

int main()
{
	//TODO: Use different values of test and rows to evaluate your code
	srand(time(0));
	string test = "was it a cat i saw";
	int rows = 10;
	cout << boolalpha;
	cout << "Input String: " << test << endl;
	cout << "Is it a palindrome?: " << isPalindrome(test) << endl;
	cout << "After randomizing: " << rearrange(test) << endl;
	cout << "The first " << rows << " rows of Pascal's triangle" << endl;
	vector<vector<int>> triangle = p_triangle(rows);
	for (vector<int> row : triangle) {
		for (int val : row) {
			cout << val << " ";
		}
		cout << endl;
	}
}
