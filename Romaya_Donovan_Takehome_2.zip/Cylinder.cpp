#define _USE_MATH_DEFINES
#include "Cylinder.h"
#include <math.h>
#include <iostream>
using namespace std;

Cylinder::Cylinder() {
	radius = 0;
	height = 0;
}

Cylinder::Cylinder(int r, int h) {
	 radius = r;
	 height = h;
}

void Cylinder::setRadius(int r) {
	radius = r;
}

void Cylinder::setHeight(int h) {
	height = h;
}

int Cylinder::getRadius() {
	return radius;
}

int Cylinder::getHeight() {
	return height;
}

int Cylinder::getVolume() {
	int volume;
	volume = M_PI*(radius * radius)*height;
	return volume;
}

int Cylinder::getSurfaceArea() {
	int SurfaceArea;
	SurfaceArea = (2* M_PI * radius * height) + (2*( M_PI *(radius * radius)));
	return SurfaceArea;
}

int Cylinder::compareVolume(Cylinder other) {
	if (getVolume() < other.getVolume()) {
		return -1;
	}
	else if (getVolume() > other.getVolume()) {
		return 1;
	}
	else {
		return 0;
	}
}

int Cylinder::compareSurfaceArea(Cylinder other) {
	if (getSurfaceArea() < other.getSurfaceArea()) {
		return -1;
	}
	else if (getSurfaceArea() > other.getSurfaceArea()) {
		return 1;
	}
	else {
		return 0;
	}
}