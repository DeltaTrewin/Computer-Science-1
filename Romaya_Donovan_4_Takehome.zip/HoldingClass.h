#pragma once
#include "GoodItem.h"
#include "BadItem.h"
#include <string>
using namespace std;

class HoldingClass {
private:
	GoodItem* good_data;
	BadItem* bad_data;
	string hold_name;
public:
  HoldingClass();
  HoldingClass(int, int, string);
  void PrintInfo();
  ~HoldingClass();
};