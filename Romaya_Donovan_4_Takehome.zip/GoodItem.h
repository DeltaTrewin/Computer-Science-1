#pragma once
class GoodItem
{
private:
	int* data;
  int len;
public:
	GoodItem();
	GoodItem(int);
  void PrintInfo();
  ~GoodItem();
};

