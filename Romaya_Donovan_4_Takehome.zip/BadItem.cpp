#include "BadItem.h"
#include <iostream>
using namespace std;

//TODO Create the empty constructor, with data assigned to a new double(0)
//and len equal to 0

BadItem::BadItem() {
	data = new double(0);
	len = 0;
}

//TODO Create the constructor taking a single int parameter n
//data should be set to a new double array of size n, and filled with 0s
//Then len is set to n

BadItem::BadItem(int n) {
	data = new double[n];
	len = n;
	for (int i = 0; i < n; i++) {
		data[i] = 0;
	}

}

//TODO Write PrintInfo to print out len, and the memory usage of data
//using len * sizeof(double)

void BadItem::PrintInfo(){
	cout << "This BadItem has " << len << " doubles" << " using " << len * sizeof(double) << " bytes" << endl;
	
}

//TODO Write the destructor, which DOES NOT properly delete the data pointer
// It should print out how many bytes are being wasted because of this

BadItem::~BadItem() {
	cout << "BadItem is going away without cleaning up after itself, wasting " << len * sizeof(double) << " bytes!" << endl;

}
