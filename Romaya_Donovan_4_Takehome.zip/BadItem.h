#pragma once
class BadItem
{
private:
  double* data;
  int len;
public:
  BadItem();
  BadItem(int);
  void PrintInfo();
  ~BadItem();
};

