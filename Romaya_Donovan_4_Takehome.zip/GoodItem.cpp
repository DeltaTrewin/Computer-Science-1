#include "GoodItem.h"
#include <iostream>
using namespace std;

//TODO Create the empty constructor, with data assigned to a new int(0)
//and len equal to 0


GoodItem::GoodItem() {
	data = new int(0);
	len = 0;
}

//TODO Create the constructor taking a single int parameter n
//data should be set to a new int array of size n, and filled with 0s
//Then len is set to n

GoodItem::GoodItem(int n) {
	data = new int[n];
	len = n;
	for (int i = 0; i < n; i++) {
		data[i] = 0;
	}

}

//TODO Write PrintInfo to print out len, and the memory usage of data
//using len * sizeof(int)

void GoodItem::PrintInfo() {
	cout << "This GoodItem has " << len << " ints" << " using " << len * sizeof(int) << " bytes" << endl;
	
}

//TODO: Write the destructor, which properly deletes the data pointer
//// and prints out how many bytes are being reclaimed because of this

GoodItem::~GoodItem() {
	cout << "GoodItem destructor called, I clean up after myself!" << endl;

}
