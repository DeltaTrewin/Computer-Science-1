// 4_Takehome.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "HoldingClass.h"

using namespace std;

//TODO: write a function called worker
//It takes no parameters and returns void
//It creates a HoldingClass item with 100 as both int parameters,
//and "Big Waste" as the string parameter
//then does nothing else

void worker() {
	HoldingClass item(100, 100, "Big Waste");
}

//TODO: Fill out main to do the following:
//1) read in two integers, and a string from the user (check)
//2) Create a non-pointer HoldingClass object with the empty constructor (check)
//3) Call the worker function (check)
//4) Create a pointer HoldingClass object using the values read in from the user (check)
//5) Call the pointer object's PrintInfo() function (check)
//6) delete the pointer object (check)

int main()
{
	int num1, num2;
	string item;
	cout << "Enter the number of int items to the store: " << endl;
	cin >> num1;
	

	cout << "Enter the number of double items to the store: " << endl;
	cin >> num2;
	

	cout << "Enter the name of the HoldingClass Object: " << endl;
	cin >> item;
	

	HoldingClass NewHoldingClass;

	worker();

	HoldingClass* holding_Ptr = new HoldingClass(num1, num2, item);

	holding_Ptr -> PrintInfo();

	delete holding_Ptr;
	

}
