#include "HoldingClass.h"
#include <iostream>
using namespace std;

//TODO Create the empty holding class constructor
// good_data should be assigned to a new empty constructor GoodItem
// bad_data should be assigned to a new empty constructor BadItem
// hold_name should be assigned "empty constructor"

HoldingClass::HoldingClass() {

	good_data = new GoodItem();
	bad_data = new BadItem();
	hold_name = "empty constructor";
}


//TODO Create the parameterized holding class constructor
//Taking two ints, good_count and bad_count, and a string new_name
// good_data should be assigned to a new GoodItem constructed with good_count
// bad_data should be assigned to a new BadItem constructed with bad_count
// hold_name should be assigned from new_name

HoldingClass::HoldingClass(int good_count, int bad_count, string new_name) {
	good_data = new GoodItem(good_count);
	bad_data = new BadItem(bad_count);
	hold_name = new_name;
}


//TODO Create the PrintInfo function, which uses cout to
//print "My name is: " followed by hold_name, then
//calls PrintInfo of both good_data and bad_data

void HoldingClass::PrintInfo() {
	cout << "My name is: " << hold_name << endl;
	good_data->PrintInfo();
	bad_data->PrintInfo();

}


//TODO Create the destructor
// It uses cout to print hold_name and declare that it's been called
// Then delete both good_data and bad_data

HoldingClass::~HoldingClass() {
	cout << "Holdingclass " << hold_name << " destructor called!" << endl;
	delete good_data; 
	delete bad_data;

}
