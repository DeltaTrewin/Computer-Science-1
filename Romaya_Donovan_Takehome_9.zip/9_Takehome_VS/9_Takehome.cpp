// 9_Takehome.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include <iostream>
#include<string>
#include "listType.h"
using namespace std;

int main() {

    listType<int> fibonacci = listType<int>(20);
    listType<string> userInput = listType<string>(5);

    fibonacci.insert(1);
    fibonacci.insert(1);
    
    //TODO: Write a for loop to fill the for loop with elements
    // of the fibonacci sequence. Use isFull() as your terminating condition 
    //Fibonacci reminder: f(n) = f(n-1) + f(n-2)
    
    for (int i = 2; !fibonacci.isFull(); i++) {
        fibonacci.insert(fibonacci.get(i - 1) + (fibonacci.get(i - 2)));
    }

    fibonacci.remove(55);
    cout << fibonacci;

    cout << "Location of 89: " << fibonacci.search(89) << endl;
    cout << "Location of 14: " << fibonacci.search(14) << endl;

    string val;
    do{
        cout << "Enter a string to insert" << endl;
        getline(cin, val);
        if (val != "") {
        userInput.insert(val);
        }
    } while (val != "");

    //TODO: prompt the user for a string to search for
    // in userInput and remove it if it is there

    string search;
    cout << "Enter a stringn to search for: ";
    getline(cin, search);
    cout << endl;
    int searchRes = userInput.search(search);
    if (searchRes != -1) {
        userInput.remove(search);
    }

    cout << userInput;
    userInput.destroyList();
}
