#pragma once
#include<iostream>

template <class elemType>
class listType
{
public:
	bool isEmpty() const;
	bool isFull() const;
	elemType get(int) const;
	int search(const elemType& searchItem) const;
	void insert(const elemType& newElement);
	void remove(const elemType& removeElement);
	void destroyList();
	listType();
	listType(int);
	friend std::ostream& operator<< (std::ostream& os, const listType<elemType>& lt) {
	//TODO: Implement printing of the entire list
		for (int i = 0; i < lt.curLength; i++) {
			os << lt.get(i) << std::endl;
		}
			return os;
	}

protected:
	elemType *list;
	int maxLength;
	int curLength;
};

//TODO: Fill in the isEmpty() function
//I'm giving you this function signature as an example
template<class elemType>
bool listType<elemType>::isEmpty() const {
	if (list == nullptr) {
		return true;
	}
	return false;
}

//TODO: Write all the remaining functions of the listType<elemType> class
template<class elemType>
bool listType<elemType>::isFull() const {
	return (curLength == maxLength);
}

template<class elemType>
elemType listType<elemType>::get(int in) const {
	return list[in];
}

template<class elemType>
int listType<elemType>::search(const elemType& searchItem) const {
	int i;
	for (i = 0; i < curLength; i++) {
		if (list[i] == searchItem) {
			return i;
		}
	}
	return -1;
}
template<class elemType>
void listType<elemType>::insert(const elemType& newElement){ 
	int i;
	int newmx;
	if (!isFull()) {
		list[curLength] = newElement;
	}else{
		newmx = maxLength * 2;
		elemType* newlst = new elemType[newmx];
		for (i = 0; i < curLength; i++) {
			newlst[i] = list[i];
		}
		delete[] list;
		list = newlst;
		maxLength = newmx;
		
	}
	curLength++;
}

template<class elemType>
void listType<elemType>::remove(const elemType& removeElement){
	int dex;
	int i;
	dex = search(removeElement);
	if (dex != -1) {
		for (i = dex; i < curLength - 1; i++) { 
			list[i] = list[i + 1];
		}
		curLength -= 1;
	}
}

template<class elemType>
void listType<elemType>::destroyList(){
	delete[] list;
	maxLength = 100;
	curLength = 0;
	list = new elemType[maxLength];
}

template<class elemType>
listType<elemType>::listType() {
	maxLength = 100;
	curLength = 0;
	list = new elemType[maxLength];
}

template<class elemType>
listType<elemType>::listType(int siz) {
	maxLength = siz;
	curLength = 0;
	list = new elemType[maxLength];
}