#include "Simple_Image.h"
#include <iostream>
using namespace std;

Simple_Image::Simple_Image(int x, int y) {
	int i, j;
	this -> x = x;
	this -> y = y; 
	pixels = new unsigned char**[x];
	for (i = 0; i < x; i++) {
		pixels[i] = new unsigned char* [y];
		for (j = 0; j < y; j++) {
			pixels[i][j] = new unsigned char [3];
		}
	}
	cout << "Created " << endl;
}

Simple_Image::~Simple_Image() {
	int i, j;
	for (i = 0; i < x; i++) {
		for (j = 0; j < y; j++) {
			delete[] pixels[i][j];
		}
		delete[] pixels[i];
	}
	delete[] pixels;
	cout << "Erased " << endl;
}

void Simple_Image::fill(const unsigned char color[]) {
	int i, j;
	for (i = 0; i < x; i++) {
		for (j = 0; j < y; j++) {
			pixels[i][j][0] = color[0];
			pixels[i][j][1] = color[1];
			pixels[i][j][2] = color[2];
		}
	}
}

void Simple_Image::set_point(int x, int y, const unsigned char color[]) {
	pixels[x][y][0] = color[0];
	pixels[x][y][1] = color[1];
	pixels[x][y][2] = color[2];
}

Simple_Image Simple_Image::operator+(const Simple_Image& other) const {
	Simple_Image New(this->x, this->y);
	int i, j, k;
	for (i = 0; i < x; i++) {
		for (j = 0; j < y; j++) {
			for (k = 0; k < 3; k++) {
				if (pixels[i][j][k] + other.pixels[i][j][k] > 255) {
					New.pixels[i][j][k] = 255;
				}
				else {
					New.pixels[i][j][k] = this->pixels[i][j][k] + other.pixels[i][j][k];
				}
			}
		}
	}
	return New;
}

Simple_Image Simple_Image::operator-(const Simple_Image& other) const {
	Simple_Image New(this->x, this->y);
	int i, j, k;
	for (i = 0; i < x; i++) {
		for (j = 0; j < y; j++) {
			for (k = 0; k < 3; k++) {
				if (pixels[i][j][k] - other.pixels[i][j][k] < 0) {
					New.pixels[i][j][k] = 0;
				}
				else {
					New.pixels[i][j][k] = this->pixels[i][j][k] - other.pixels[i][j][k];
				}
			}
		}
	}
	return New;
}

CImg<unsigned char> Simple_Image::toCImg() {
	CImg<unsigned char> res(x,y,1,3,0);
	for (int i = 0; i < x; i++) {
		for (int j = 0; j < x; j++) {
			res(i, j, 0) = pixels[i][j][0];
			res(i, j, 1) = pixels[i][j][1];
			res(i, j, 2) = pixels[i][j][2];
		}
	}
	return res;
}

void Simple_Image::save(const char* filename) {
	this->toCImg().save(filename);
}

void Simple_Image::display() {
	CImgDisplay disp(this->toCImg(), "Simple Image");
	while (!disp.is_closed()) {
		disp.wait();
	}
}
